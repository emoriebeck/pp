/**
 * jspsych-survey-text-timed
 * Josh de Leeuw
 *
 * plugin for displaying a stimulus and getting a keyboard response
 *
 * documentation: docs.jspsych.org
 *
 **/


jsPsych.plugins["survey-text-timed"] = (function() {

  var plugin = {};

  jsPsych.pluginAPI.registerPreload('single-stim', 'stimulus', 'image');

  plugin.trial = function(display_element, trial) {

    trial.preamble = typeof trial.preamble == 'undefined' ? "" : trial.preamble;
    if (typeof trial.rows == 'undefined') {
      trial.rows = [];
      for (var i = 0; i < trial.stimulus.length; i++) {
        trial.rows.push(1);
      }
    }
    if (typeof trial.columns == 'undefined') {
      trial.columns = [];
      for (var i = 0; i < trial.stimulus.length; i++) {
        trial.columns.push(40);
      }
    }

    // if any trial variables are functions
    // this evaluates the function and replaces
    // it with the output of the function
    trial = jsPsych.pluginAPI.evaluateFunctionParameters(trial);

    // set default values for the parameters
    //trial.choices = trial.choices || [];
    trial.response_ends_trial = (typeof trial.response_ends_trial == 'undefined') ? true : trial.response_ends_trial;
    trial.timing_stim = trial.timing_stim || -1;
    trial.timing_response = trial.timing_response || -1;
    trial.is_html = (typeof trial.is_html == 'undefined') ? false : trial.is_html;
    trial.prompt = trial.prompt || "";

    // this array holds handlers from setTimeout calls
    // that need to be cleared if the trial ends early
    var setTimeoutHandlers = [];

    // display stimulus
    if (!trial.is_html) {
      display_element.append($('<img>', {
        src: trial.stimulus,
        id: 'jspsych-survey-text-timed-stimulus'
      }));
    } else {
      display_element.append($('<div>', {
        html: trial.stimulus,
        id: 'jspsych-survey-text-timed-stimulus'
      }));
    }

    // show preamble text
    display_element.append($('<div>', {
      "id": 'jspsych-survey-text-timed-preamble',
      "class": 'jspsych-survey-text-timed-preamble'
    }));

    $('#jspsych-survey-text-timed-preamble').html(trial.preamble);

    // add questions
    for (var i = 0; i < 1; i++) { //trial.stimulus.length; i++) {
      // create div
      display_element.append($('<div>', {
        "id": 'jspsych-survey-text-timed-' + i,
        "class": 'jspsych-survey-text-timed-question'
      }));

      // add question text
      $("#jspsych-survey-text-timed-" + i).append('<p class="jspsych-survey-text-timed">' + trial.stimulus + '</p>');

      // add text box
      $("#jspsych-survey-text-timed-" + i).append('<textarea name="#jspsych-survey-text-timed-response-' + i + '" cols="' + trial.columns[i] + '" rows="' + trial.rows[i] + '"></textarea>');
    }

    // add submit button
    display_element.append($('<button>', {
      'id': 'jspsych-survey-text-timed-next',
      'class': 'jspsych-btn jspsych-survey-text-timed'
    }));
    $("#jspsych-survey-text-timed-next").html('Submit Answers');
    $("#jspsych-survey-text-timed-next").click(function() {
      // measure response time
      var endTime = (new Date()).getTime();
      var response_time = endTime - startTime;

      // create object to hold responses
      var question_data = {};
      $("div.jspsych-survey-text-timed-question").each(function(index) {
        var id = "Q" + index;
        var val = $(this).children('textarea').val();
        var obje = {};
        obje[id] = val;
        $.extend(question_data, obje);
      });

      // kill any remaining setTimeout handlers
      for (var i = 0; i < setTimeoutHandlers.length; i++) {
        clearTimeout(setTimeoutHandlers[i]);
      }

      // save data
      var trial_data = {
        "rt": response.rt,
        "stimulus": trial.stimulus,
        "responses": response.responses
      };

      display_element.html('');

      // next trial
      jsPsych.finishTrial(trialdata);
  });

    //show prompt if there is one
    if (trial.prompt !== "") {
      display_element.append(trial.prompt);
    }

    // save data
    var trialdata = {
      "rt": response_time,
      "responses": JSON.stringify(question_data)
    };


    // function to end trial when it is time
    // var end_trial = function() {
    //
    //   // kill any remaining setTimeout handlers
    //   for (var i = 0; i < setTimeoutHandlers.length; i++) {
    //     clearTimeout(setTimeoutHandlers[i]);
    //   }
    //
    //   // kill keyboard listeners
    //   // if (typeof keyboardListener !== 'undefined') {
    //   //   jsPsych.pluginAPI.cancelKeyboardResponse(keyboardListener);
    //   // }
    //
    //   // gather the data to store for the trial
    //   var trial_data = {
    //     "rt": response.rt,
    //     "stimulus": trial.stimulus,
    //     "responses": response.responses
    //   };
    //
    //   //jsPsych.data.write(trial_data);
    //
    //   // clear the display
    //   display_element.html('');
    //
    //   // move on to the next trial
    //   jsPsych.finishTrial(trial_data);
    // };
    var startTime = (new Date()).getTime();

    // // function to handle responses by the subject
    // var after_response = function(info) {
    //
    //   // after a valid response, the stimulus will have the CSS class 'responded'
    //   // which can be used to provide visual feedback that a response was recorded
    //   $("#jspsych-survey-text-timed-stimulus").addClass('responded');
    //
    //   // only record the first response
    //   // if (response.key == -1) {
    //   //   response = info;
    //   // }
    //
    //   if (trial.response_ends_trial) {
    //     end_trial();
    //   }
    // };

    // start the response listener
    // if (JSON.stringify(trial.choices) != JSON.stringify(["none"])) {
    //   var keyboardListener = jsPsych.pluginAPI.getKeyboardResponse({
    //     callback_function: after_response,
    //     valid_responses: trial.choices,
    //     rt_method: 'date',
    //     persist: false,
    //     allow_held_key: false
    //   });
    // }

    // hide image if timing is set
    if (trial.timing_stim > 0) {
      var t1 = setTimeout(function() {
        $('#jspsych-survey-text-timed-stimulus').css('visibility', 'hidden');
      }, trial.timing_stim);
      setTimeoutHandlers.push(t1);
    }

    // end trial if time limit is set
    if (trial.timing_response > 0) {
      var t2 = setTimeout(function() {
        end_trial();
      }, trial.timing_response);
      setTimeoutHandlers.push(t2);
    }

};
  return plugin;
})();
